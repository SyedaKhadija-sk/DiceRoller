# Hello, I excited to share my third task "Dice Roller"

import random
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk

# Function to simulate rolling a Dice and get random results
def roll_dice(num_dice):
    dice_images = ["image/dicee1.png", "image/dicee2.png", "image/dicee3.png", "image/dicee4.png", "image/dicee5.png",
                   "image/dicee6.png"]
    dice_results = [random.choice(dice_images) for _ in range(num_dice)]
    return dice_results

# Function to clear dice labels
def clear_dice_labels():
    for label in dice_labels:
        label.configure(image=None)
        label.image = None

# Function called when the roll button is clicked
def on_roll_button_click():
    try:
        num_dice = int(entry.get())
        if 1 <= num_dice <= 4:
            # Clear existing dice labels
            clear_dice_labels()
            dice_results = roll_dice(num_dice)

            # Update labels with new dice results
            for i, result_image in enumerate(dice_results):
                new_image = ImageTk.PhotoImage(Image.open(result_image))
                dice_labels[i].configure(image=new_image)
                dice_labels[i].image = new_image

                # Adjust the positions of the dice based on the number of dice rolled
                if num_dice == 1:
                    for i, label in enumerate(dice_labels):
                        label.place(x=250 + i * 120, y=150)

                elif num_dice == 2:
                    for i, label in enumerate(dice_labels):
                        label.place(x=200 + i * 120, y=150)
                    # dice_labels[i].place(x=200 + i * 120, y=150)
                elif num_dice == 3:
                    for i, label in enumerate(dice_labels):
                        label.place(x=150 + i * 120, y=150)
                    # dice_labels[i].place(x=150 + i * 120, y=150)
                elif num_dice == 4:
                    dice_labels[i].place(x=80 + i * 120, y=150)


        else:
            # Show an error message if the entered number is not between 1 and 4
            messagebox.showinfo("Error", "Please enter a number between 1 and 4.")
    except ValueError:
        # Show an error message if the entered value is not a valid number
        messagebox.showinfo("Error", "Please enter a valid number of dice.")

# Function called when the enter button is clicked
def on_enter_button_click():
    on_roll_button_click()

# Create the main window
window = tk.Tk()
window.geometry("630x360")
window.title("Dice Roll App")

# Set resizable to both dimensions
window.resizable("False", "False")

# Create and place dice labels
dice_labels = []
for i in range(4):
    label = tk.Label(window, image=None, bg="#EC7625")
    label.place(x=45 + i * 120, y=150)
    dice_labels.append(label)

# Create and place entry widget for user input
entry = tk.Entry(window, width=17, font=("Helvetica", 16))
entry.place(x=190, y=80)

# Create and place roll button with styling
roll_button = tk.Button(window, text="ROLL", bg="#F5A623", fg="white", font="Times 20 bold", command=on_roll_button_click)
roll_button.place(x=250, y=17)

# Create and place enter button for user input
enter_button = tk.Button(window, text="Dice", bg="#75CFB8", fg="white", font="Helvetica 10 bold", command=on_enter_button_click)
enter_button.place(x=415, y=80)

# Create and place delete icon button with functionality
delete_icon_path = "image/del.png"
delete_image = Image.open(delete_icon_path)
delete_image_resized = delete_image.resize((30, 30))
delete_icon = ImageTk.PhotoImage(delete_image_resized)
delete_button = tk.Button(window, image=delete_icon, command=clear_dice_labels)
delete_button.place(x=580, y=300)

# Set initial background color
window.config(bg="#EC7625")

# Start the main loop
window.mainloop()

# Happy Coding!
